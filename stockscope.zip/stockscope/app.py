import pandas as pd
import streamlit as st
from dotenv import load_dotenv

from src.data import fetch
from src.ratios import compute
from src.redflags import detect
from src.scoring import score
from src.ai_summary import explain, DISCLAIMER
from src.glossary import GLOSSARY

load_dotenv()
st.set_page_config(page_title="StockScope", page_icon="📊", layout="centered")


@st.cache_data(ttl=3600, show_spinner=False)
def analyse(ticker: str):
    data = fetch(ticker)
    m = compute(data)
    flags = detect(m)
    res = score(m, flags)
    return m, flags, res


def f(v, kind="num"):
    if v is None:
        return "n/a"
    return f"{v:.1%}" if kind == "pct" else f"{v:,.2f}"


st.title("📊 StockScope")
st.caption("Type a ticker. Get the checks big investors run, explained simply.")
st.warning(DISCLAIMER)

ticker = st.text_input("Ticker", placeholder="DTK.NR, KCB.NR, AAPL, BP.L")
st.caption("Use the Yahoo Finance symbol. Nairobi stocks end in .NR")

if st.button("Analyse", type="primary") and ticker.strip():
    with st.spinner("Researching..."):
        m, flags, res = analyse(ticker.strip())

    st.header(m["name"])
    c1, c2, c3 = st.columns(3)
    c1.metric("Rating", res["rating"])
    c2.metric("Score", f"{res['score']}/100")
    c3.metric("Confidence", res["confidence"])
    st.progress(res["score"] / 100)

    st.subheader("Key numbers")
    rows = [
        ("Price", f(m["price"])), ("Market cap", f"{m['market_cap']:,.0f}" if m["market_cap"] else "n/a"),
        ("EPS", f(m["eps"])), ("P/E", f(m["pe"])), ("P/B", f(m["pb"])),
        ("Dividend yield", f(m["dividend_yield"], "pct")), ("Payout ratio", f(m["payout_ratio"], "pct")),
        ("ROE", f(m["roe"], "pct")), ("Debt/Equity", f(m["debt_to_equity"])),
        ("Profit growth", f(m["profit_growth"], "pct")), ("Revenue growth", f(m["revenue_growth"], "pct")),
    ]
    st.dataframe(pd.DataFrame(rows, columns=["Metric", "Value"]), hide_index=True, use_container_width=True)

    st.subheader("Red flags")
    if not flags:
        st.success("None detected in the available data.")
    icons = {"high": "🔴", "medium": "🟠", "info": "ℹ️"}
    for fl in flags:
        st.write(f"{icons[fl['level']]} {fl['text']}")

    if m["net_income_series"] is not None:
        st.subheader("Profit trend")
        s = m["net_income_series"].copy()
        s.index = [str(d.year) for d in s.index]
        st.bar_chart(s)

    st.subheader("AI analysis")
    with st.spinner("Writing analysis..."):
        st.markdown(explain(m, flags, res))

    with st.expander("Why this score?"):
        for pts, why in res["why"]:
            st.write(f"{pts:+d}  {why}")
    st.caption("Source: Yahoo Finance via yfinance. Data may be delayed or incomplete.")

with st.expander("📖 Learn the terms"):
    for k, v in GLOSSARY.items():
        st.markdown(f"**{k}**: {v}")
